public class Banque2 {
    public static void main(String[] args) {
        double tauxPrive = 0.01;
        double tauxEpargne = 0.02;

        Client client1 = new Client("Pedro", "Geneve", 1000.0, 2000.0, tauxPrive, tauxEpargne);
        Client client2 = new Client("Alexandra", "Lausanne", 3000.0, 4000.0, tauxPrive, tauxEpargne);

        client1.afficherDonnees();
        client2.afficherDonnees();

        client1.bouclerComptes();
        client2.bouclerComptes();

        client1.afficherDonnees();
        client2.afficherDonnees();
    }
}
